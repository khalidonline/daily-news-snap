"""Deliver the owner's corrected B2-06 once per approved destination."""
import hashlib
import json
from pathlib import Path
from publishing_v2.bundle_api import BundleClient, BundleError, GitHubJournal, load_package, publish
from publishing_v2.readability import require_for_new_delivery

manifest = 'approved/app-origins-revised/manifest.json'
identity, title, media = load_package(manifest)
digest = hashlib.sha256(media[0][1]).hexdigest()
if digest != '25d6af6caca0f7e3d0bcc10e7d2cb8b7ad87ca9525f09f1156be5db8dea0e85d':
    raise BundleError('Unexpected correction video')
class CorrectedChallengeClient(BundleClient):
    def call(self, path, method='GET', data=None, content_type='application/json'):
        if path == '/post' and method == 'POST':
            payload = json.loads(data)
            snap = payload['data']['SNAPCHAT']
            payload['referenceKey'] = 'B2-06-corrected-' + digest + '-' + snap['type']
            if snap['type'] == 'SPOTLIGHT':
                snap['skipSaveToProfile'] = True
            data = json.dumps(payload).encode()
        return super().call(path, method, data, content_type)

client = CorrectedChallengeClient()
client.check()
report = GitHubJournal('app-origins-revised-preflight')
for dest in ('STORY', 'SPOTLIGHT'):
    key = identity if dest == 'STORY' else hashlib.sha256((identity + ':SPOTLIGHT').encode()).hexdigest()
    journal = GitHubJournal(key)
    require_for_new_delivery(manifest, media, journal.read())
    publish(client, journal, title, media, placement=dest)
    row = journal.read()['1']
    remote = client.call('/post/' + row['post_id'])
    snap = remote['externalData']['SNAPCHAT']
    if (remote['teamId'] != client.team or remote.get('deletedAt') or remote['status'] != 'POSTED'
        or snap['status'] != 'PUBLISHED' or snap['type'] != dest
        or row['upload_id'] not in snap['sourceUploadIds']):
        raise BundleError('Pending verified receipt: ' + dest)
    state = report.read()
    state[dest] = dict(post_id=row['post_id'], media_sha256=digest, status=snap['status'])
    report.save(state)
