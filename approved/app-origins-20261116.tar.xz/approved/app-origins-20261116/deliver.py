"""One fixed, already reviewed batch-2 slot; shared ApprovedMedia transport only."""
import base64, hashlib, json
from pathlib import Path
from datetime import datetime,timezone,timedelta
from publishing_v2.bundle_api import ApprovedMedia,BundleClient,BundleError,GitHubJournal,load_package,publish
from publishing_v2.group_recovery import inventory
from publishing_v2.readability import require_for_new_delivery

pkg='app-origins-20261116'
manifest=Path('approved')/pkg/'manifest.json'
identity,title,media=load_package(str(manifest))
if not isinstance(media,ApprovedMedia) or len(media)!=1:raise BundleError('Expected one ApprovedMedia video')
video=hashlib.sha256(media[0][1]).hexdigest(); version=hashlib.sha256(manifest.read_bytes()).hexdigest()
def key(dest): return identity if dest=='STORY' else hashlib.sha256((identity+':SPOTLIGHT').encode()).hexdigest()
def ref(dest): return 'B2-06-'+key(dest)
class SlotClient(BundleClient):
    def call(self,path,method='GET',data=None,content_type='application/json'):
        if path=='/post' and method=='POST':
            payload=json.loads(data);snap=payload['data']['SNAPCHAT'];dest=snap['type']
            if dest not in ['STORY','SPOTLIGHT']:raise BundleError('Unexpected placement')
            payload['referenceKey']=ref(dest)
            if dest=='SPOTLIGHT':snap['skipSaveToProfile']=True
            data=json.dumps(payload).encode()
        return super().call(path,method,data,content_type)
client=SlotClient();client.check()
report=GitHubJournal(pkg+'-preflight')
def record(k,v):
    s=report.read();s[k]=v;report.save(s)
localday='2026-11-16'
def slot_guard():
    now=datetime.now(timezone(timedelta(hours=3)))
    if now.date().isoformat()!=localday or not 13<=now.hour<19:raise BundleError('Outside reserved slot')
    row=report.call('/contents/challenge-queue/batch-2-position.json?ref=snapchat-api-state')
    pos=json.loads(base64.b64decode(row['content']))
    if pos['next_item']!='B2-06' or pos['status']!='SLOT_RESERVED' or pos.get('reserved_version')!=version:raise BundleError('Queue reservation changed')
slot_guard()
record('budget',dict(new_paid_model_requests=0,total_daily_spend='UNKNOWN',limit_usd=3))
for dest in ('STORY','SPOTLIGHT'):
    slot_guard()
    intent=GitHubJournal(pkg+'-intent-'+dest.lower());j=GitHubJournal(key(dest))
    s=intent.read();state=j.read();row=state.get('1',{})
    if (s['approved_version'],s['media_sha256'],s['identity'],s['destination'],s['provider_journal_key'],s['reference_key'])!=(version,video,identity,dest,key(dest),ref(dest)):raise BundleError('Intent mismatch')
    rows=inventory(client); matches=[r for r in rows if r.get('referenceKey')==ref(dest)]
    # Guard against alternate prior publications using the same topic but another file.
    for r in rows:
        if r.get('referenceKey') in (ref('STORY'),ref('SPOTLIGHT')):continue
        ttl=r.get('title') or ''
        if ('إنستقرام' in ttl and 'سناب' in ttl) or ('instagram' in ttl.lower() and 'snap' in ttl.lower()):raise BundleError('Previously attempted topic: reconcile before sending')
    if len(matches)>1:raise BundleError('Ambiguous reference')
    pid=row.get('post_id') or s.get('provider_post_id')
    if matches:
        if (pid and pid!=matches[0]['id']) or (not row.get('upload_id')):raise BundleError('Reference or upload mismatch')
        pid=matches[0]['id']
    if pid:client.wait(pid)
    else:
        if row or matches or s['state']!='INTENT_RECORDED':raise BundleError('Unresolved earlier request; no resend')
        require_for_new_delivery(str(manifest),media,state)
        quota=client.ensure_capacity(4 if dest=='STORY' else 3)
        record('quota_'+dest,quota)
        # Zero other sends today is sufficient evidence of available daily challenge slots.
        # If unrelated content has already used quota, stop for separate classification.
        if quota['posts']['used']>(0 if dest=='STORY' else 1):raise BundleError('Other daily usage needs reconciliation')
        slot_guard();s['state']='STARTED';intent.save(s)
        publish(client,j,title,media,placement=dest)
        row=j.read()['1'];pid=row['post_id']
    remote=client.call('/post/'+pid)
    external=(remote.get('externalData') or {}).get('SNAPCHAT') or {}
    if not (remote.get('id')==pid and remote.get('teamId')==client.team and not remote.get('deletedAt') and remote.get('status')=='POSTED' and external.get('status')=='PUBLISHED' and external.get('type')==dest and row.get('upload_id') in (external.get('sourceUploadIds') or []) and external.get('id')):raise BundleError('Receipt unresolved: no repeat')
    s=intent.read();s.update(state='POSTED',provider_post_id=pid,snapchat_status='PUBLISHED',upload_id=row['upload_id']);intent.save(s)
    record(dest,dict(status='POSTED',post_id=pid,externalData={'SNAPCHAT':external},media_sha256=video,reference_key=ref(dest)))
